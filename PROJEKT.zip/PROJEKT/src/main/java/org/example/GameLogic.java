package org.example;

import org.example.logic.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Random;

public class GameLogic implements KeyListener {
    ArrayList<Bird> birds, birdsRemove;
    ArrayList<Bird> blueBirds, birdsRemove2;
    ArrayList<Bird> deadBirds, birdsRemove3;
    boolean shoot;
    int windowWidth, windowHeight;
    Player player;
    ArrayList<Bullet> bullets, bulletsRemove;
    int spawnTimer, spawnInterval;
    int score;
    int level;
    int shootTimer;
    boolean gameActive;
    boolean infoActive;
    boolean level2Increased;
    boolean level3Increased;
    Random random;

    public GameLogic(int windowWidth, int windowHeight) {
        this.windowHeight = windowHeight;
        this.windowWidth = windowWidth;
        birds = new ArrayList<>();
        blueBirds = new ArrayList<>();
        deadBirds = new ArrayList<>();
        bullets = new ArrayList<>();
        player = new Player(10, 335, 100, 160, "player.png", "player2.png");
        bulletsRemove = new ArrayList<>();
        birdsRemove = new ArrayList<>();
        birdsRemove2 = new ArrayList<>();
        birdsRemove3 = new ArrayList<>();
        random = new Random();
        this.score = 0;
        this.level = 1;
        this.shootTimer = 0;
        this.gameActive = false;
        this.infoActive = false;
        this.level2Increased = false;
        this.level3Increased = false;
    }

    public int getScore() {
        return score;
    }

    public int getLevel() {
        return level;
    }

    public void update() {
        if (!gameActive) {
            return;
        }

        player.move(windowWidth);

        spawnTimer++;
        if (spawnTimer >= spawnInterval) {
            int randomHeight = random.nextInt(20) + 50;
            switch (random.nextInt(1, 4)) {
                case 1 -> birds.add(new Bird(-100, randomHeight, 100, 70, "bird.gif"));
                case 2 -> blueBirds.add(new Bird(-100, randomHeight, 80, 50, "bird2.gif"));
                case 3 -> deadBirds.add(new Bird(-100, randomHeight, 110, 80, "bird3.gif"));
            }
            spawnTimer = 0;
        }

        if (score >= 0 && score < 40) {
            spawnInterval = random.nextInt(150, 400);
        } else if (score >= 40 && score < 65) {
            spawnInterval = random.nextInt(50, 100);
        } else {
            spawnInterval = random.nextInt(20, 100);
        }


        if (score >= 40 && !level2Increased) {
            level += 1;
            level2Increased = true;
        }

        if (score >= 65 && !level3Increased) {
            level += 1;
            level3Increased = true;
        }

        for (Bird bird : birds) {
            bird.move();
            if (bird.x > windowWidth) {
                birdsRemove.add(bird);
            }
        }

        for (Bird bird : blueBirds) {
            bird.move();
            if (bird.x > windowWidth) {
                birdsRemove2.add(bird);
            }
        }
        for (Bird bird : deadBirds) {
            bird.move();
            if (bird.x > windowWidth) {
                birdsRemove3.add(bird);
            }
        }

        for (Bullet bullet : bullets) {
            bullet.move();
            if (bullet.x <= 0) {
                bulletsRemove.add(bullet);
            }
            if (bullet.x >= 1080 - bullet.getWidth()) {
                bulletsRemove.add(bullet);
            }
            if (bullet.y <= 0) {
                bulletsRemove.add(bullet);
            }
            for (Bird bird : birds) {
                if (bullet.getRectangle().intersects(bird.getRectangle())) {
                    bulletsRemove.add(bullet);
                    birdsRemove.add(bird);
                    score += 1;
                }
            }
            for (Bird bird : blueBirds) {
                if (bullet.getRectangle().intersects(bird.getRectangle())) {
                    bulletsRemove.add(bullet);
                    birdsRemove2.add(bird);
                    score += 3;
                }
            }
            for (Bird bird : deadBirds) {
                if (bullet.getRectangle().intersects(bird.getRectangle())) {
                    bulletsRemove.add(bullet);
                    birdsRemove3.add(bird);
                    gameActive = false;
                    score = 0;
                }
            }
        }
        shootTimer++;
        if (shoot && shootTimer >= 70) {
            bullets.add(new Bullet(player.getY(), 20, 90, "bullet.png", player));
            shoot = false;
            shootTimer = 0;
        } else {
            shoot = false;
        }

        bullets.removeAll(bulletsRemove);
        birds.removeAll(birdsRemove);
        blueBirds.removeAll(birdsRemove2);
        deadBirds.removeAll(birdsRemove3);
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_SPACE -> shoot = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_S && !gameActive) {
            gameActive = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_ESCAPE && !gameActive) {
            System.exit(0);
        }
        if (e.getKeyCode() == KeyEvent.VK_I) {
            infoActive = !infoActive;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {}
}
