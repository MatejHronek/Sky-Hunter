package org.example;

import org.example.logic.Direction;

import javax.swing.*;
import java.awt.event.*;
import java.sql.PreparedStatement;

public class Game implements Runnable{
    GameLogic logic;
    int winWidth = 1080, winHeight = 720;
    GameGraphics graphic;

    public static void main(String[] args) {
        new Game();
    }

    public Game() {
        logic = new GameLogic(winWidth, winHeight);
        graphic = new GameGraphics(logic, winWidth, winHeight);

        Thread thread = new Thread(this);
        thread.start();

    }

    @Override
    public void run() {
        while (true){
            if (logic.gameActive){
                logic.update();
            }
            graphic.render(logic);
        try {
                Thread.sleep(1000/60);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }

    }
}
