    package org.example.logic;

    import javax.imageio.ImageIO;
    import java.awt.*;
    import java.awt.image.BufferedImage;
    import java.io.File;
    import java.io.IOException;

    public class Entity extends Coordinates{
        protected int width;
        protected int height;
        protected BufferedImage image;

        public Entity(int x, int y, int width, int height, String url) {
            super(x,y);
            this.width = width;
            this.height = height;

            try {
                image = ImageIO.read(new File("src/main/resources/" + url));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        }

        public Rectangle getRectangle(){
            return new Rectangle(x,y,width, height);
        }


        public int getX() {
            return x;
        }

        public void setX(int x) {
            this.x = x;
        }

        public int getY() {
            return y;
        }

        public void setY(Bird y) {
            this.y = 5;
        }

        public int getWidth() {
            return width;
        }

        public void setWidth(int width) {
            this.width = width;
        }

        public int getHeight() {
            return height;
        }

        public void setHeight(int height) {
            this.height = height;
        }

        public Image getImage() {
            return image;
        }

    }
