package org.example.logic;

public class Bullet extends Entity{
    int speed = 10;
    boolean left, right;
    public Bullet(int y, int width, int height, String url, Player player) {
        super(0, y, width, height, url);
        if (player.image == player.player2){
            left = true;
            x = player.x;
        }
        if (player.image == player.player1){
            right = true;
            x = player.x + player.width;
        }
    }

    public void move(){
        if (right){
            y -= speed;
            x += 15;
        }
        else{
            y -= speed;
            x -= 15;
        }
    }

}
