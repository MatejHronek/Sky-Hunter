package org.example.logic;

import javax.imageio.ImageIO;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Player extends Entity implements KeyListener {
    boolean left, right;
    int speed = 5;
    BufferedImage player1;
    BufferedImage player2;


    public Player(int x, int y, int width, int height, String url, String file) {
        super(x, y, width, height, url);
        try {
            player1 = ImageIO.read(new File("src/main/resources/" + url));
            player2 = ImageIO.read(new File("src/main/resources/" + file));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }



    public void move(int winWidth){
        if(left){
            x -= speed;
            image = player2;
        }
        if(right){
            x += speed;
            image = player1;
        }
        if(x <= 0){
            x = 0;
        }
        if(x >= winWidth - width){
            x = winWidth - width;
        }



    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()){
            case KeyEvent.VK_A -> left = true;
            case KeyEvent.VK_D -> right = true;
        }

    }

    @Override
    public void keyReleased(KeyEvent e) {
        switch (e.getKeyCode()){
            case KeyEvent.VK_A -> left = false;
            case KeyEvent.VK_D -> right = false;
        }

    }
}
