package org.example.logic;

public class Bird extends Entity {
    int speed = 5;
    public Bird(int x, int y, int width, int height,String url) {
        super(x, y, width, height, url);
    }
    public void move(){
        x += speed;

    }

}
