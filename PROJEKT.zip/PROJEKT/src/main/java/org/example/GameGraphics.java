package org.example;

import org.example.logic.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class GameGraphics extends JFrame {
    Draw draw;
    GameLogic logic;
    private Image bird;
    private Image Informations;
    ImageIcon birdGif;
    ImageIcon birdGif2;
    ImageIcon birdGif3;

    public GameGraphics(GameLogic logic, int winWidth, int winHeight) throws HeadlessException {
        this.draw = new Draw(winWidth, winHeight);
        this.logic = logic;
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        setTitle("Game");

        add(draw);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
        setFocusable(true);
        requestFocus();
        addKeyListener(logic.player);
        addKeyListener(logic);
        birdGif = new ImageIcon("src/main/resources/bird.gif");
        birdGif2 = new ImageIcon("src/main/resources/bird2.gif");
        birdGif3 = new ImageIcon("src/main/resources/bird3.gif");
        bird = birdGif.getImage();
        bird = birdGif2.getImage();
        bird = birdGif3.getImage();
    }

    public void render(GameLogic logic) {
        this.logic = logic;
        repaint();
    }

    public class Draw extends JPanel {
        int winWidth;
        int winHeight;
        Image backgroundImage;
        BufferedImage background;

        Draw(int winWidth, int winHeight) {
            this.winHeight = winHeight;
            this.winWidth = winWidth;
            setPreferredSize(new Dimension(winWidth, winHeight));

            backgroundImage = new ImageIcon(getClass().getResource("/background.png")).getImage();
            Informations = new ImageIcon(getClass().getResource("/informations.png")).getImage();
            try {
                background = ImageIO.read(new File("src/main/resources/startmenu.png"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        }

        public void paintComponent(Graphics g) {
            if (logic.gameActive) {
                g.drawImage(backgroundImage, 0, 0, winWidth, winHeight, this);

                for (Bullet bullet : logic.bullets) {
                    g.drawImage(bullet.getImage(), bullet.getX(), bullet.getY(), bullet.getWidth(), bullet.getHeight(), this);
                }
                g.drawImage(logic.player.getImage(), logic.player.getX(), logic.player.getY(), logic.player.getWidth(), logic.player.getHeight(), this);

                for (Bird bird : logic.birds) {
                    g.drawImage(birdGif.getImage(), bird.getX(), bird.getY(), bird.getWidth(), bird.getHeight(), this);
                }
                for (Bird bird : logic.blueBirds) {
                    g.drawImage(birdGif2.getImage(), bird.getX(), bird.getY(), bird.getWidth(), bird.getHeight(), this);
                }
                for (Bird bird : logic.deadBirds) {
                    g.drawImage(birdGif3.getImage(), bird.getX(), bird.getY(), bird.getWidth(), bird.getHeight(), this);
                }
                Font font;
                font = new Font("Zero Cool", Font.BOLD, 30);
                g.setFont(font);
                g.drawString("SCORE: " + Integer.toString(logic.getScore()), 900, 40);
            } else {
                g.drawImage(background, 0, 0, winWidth, winHeight, this);
            }
            if (logic.infoActive) {
                g.drawImage(Informations, 0, 0, winWidth, winHeight, this);
            }
            if (logic.gameActive) {
                g.drawString("LEVEL: " + Integer.toString(logic.getLevel()), 10, 40);
            }
        }
    }
}
